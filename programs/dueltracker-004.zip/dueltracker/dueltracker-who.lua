-- This file is part of DuelTracker.
-- Copyright (c) 2005, 2006 Kevin Locke <kwl7@cornell.edu>
-- DuelTracker is licensed under the terms of the MIT (aka Expat) license
-- the specific terms of the license are available in the COPYING.txt file
-- and online at http://www.opensource.org/licenses/mit-license.html

-- Functions to deal with querying the server for information (who functions)

-- whoqueue is a linked list of who queries to be made
-- each item contains {name, drkey, fails, next} 
-- (query to preform, duel to add data to, # failed who requests, next item)
local whoqueue = nil;			-- queue of who queries to perform

function DuelTracker_WhoRequestStart()
	-- Prevent FriendsFrame from noticing
	FriendsFrame:UnregisterEvent("WHO_LIST_UPDATE");

	-- Get event for results
	this:RegisterEvent("WHO_LIST_UPDATE");

	-- Force who to trigger WHO_LIST_UPDATE event
	SetWhoToUI(1);
end

function DuelTracker_WhoRequestStop()
	FriendsFrame:RegisterEvent("WHO_LIST_UPDATE");
	this:UnregisterEvent("WHO_LIST_UPDATE");
	SetWhoToUI(0);

end

function DuelTracker_AddToWhoQueue(name, drkey)
	if ( name == nil ) then
		return;
	elseif ( drkey == nil ) then
		drkey = DuelTracker_DuelRecord.size; -- Assume most recent
	end

	-- If queue is empty, set everything in motion
	if ( whoqueue == nil ) then
		whoqueue = {name = name, drkey = drkey, fails = 0, next = nil};
		-- Start OnUpdate calls
		DuelTrackerFrame:Show();
	else
		local wq = whoqueue;
		while ( wq.next ~= nil ) do
			wq = wq.next;
		end
		wq.next = {name = name, drkey = drkey, fails = 0, next = nil};
	end
	-- No need to send who request, will be called in time from OnUpdate
end

function DuelTracker_HandleWhoData()
	-- Stop receiving events while processing (to allow user to who)
	DuelTracker_WhoRequestStop();

	if ( whoqueue == nil ) then
		DuelTracker_Message("Who results returned, "..
				   "but none in queue.", 7, true);
		return;
	end

	local numWhos, totalCount = GetNumWhoResults();
	local name, guild, level, race, class, zone, group;
	local i = 1;

	-- Scan who results
	repeat
		name, guild, level, race, class, zone, group = GetWhoInfo(i);
		i = i + 1;
	until ( name == nil or name == "" or
		name == whoqueue.name or i > numWhos )

	-- name may not match because query is for member of opposing faction
	-- or the user made a request at the same time we did
	if ( name ~= whoqueue.name ) then
		DuelTracker_WhoRequestStart();
		
		whoqueue.fails = whoqueue.fails + 1;

		DuelTracker_Message("Who query results did not match "..
				   whoqueue.name..".", 7);
		DuelTracker_Message("Failures for "..whoqueue.name..
				   ":  "..whoqueue.fails, 7);

		-- 3 failures probably means player is opposing faction
		if ( whoqueue.fails > 2 ) then
			whoqueue = whoqueue.next;
		end

		-- Mimic normal response, only print 1 result for clarity
		-- If numWhos == 0, don't know if user triggered or not
		if ( numWhos > 0 ) then
			DuelTracker_Message(name..": Level "..level.." "..race..
					   " "..  class.." <"..guild.."> - "..
					   zone..".", 3);
			if ( numWhos > 1 ) then
				DuelTracker_Message(numWhos.." players total."..
					   "  1 displayed by DuelTracker.", 3);
			else
				DuelTracker_Message("1 player total", 3);
			end
		end
		return;
	end

	local drkey = whoqueue.drkey;
	if ( DuelTracker_DuelRecord[drkey].winner.name == name ) then
		DuelTracker_DuelRecord[drkey].winner.race = race;
		DuelTracker_DuelRecord[drkey].winner.class = class;
		DuelTracker_DuelRecord[drkey].winner.level = level;
		DuelTracker_DuelRecord[drkey].winner.guild = guild;
		DuelTracker_Message("Added winner who data for "..
				   whoqueue.name..".", 6);
	elseif ( DuelTracker_DuelRecord[drkey].loser.name == name ) then
		DuelTracker_DuelRecord[drkey].loser.race = race;
		DuelTracker_DuelRecord[drkey].loser.class = class;
		DuelTracker_DuelRecord[drkey].loser.level = level;
		DuelTracker_DuelRecord[drkey].loser.guild = guild;
		DuelTracker_Message("Added loser who data for "..
				   whoqueue.name..".", 6);
	else
		DuelTracker_Message("Unable to find record for "..name..".", 7);
	end

	-- Add player information to cache
	if ( DuelTracker_PlayerCache[name] ) then
		DuelTracker_Message("Unnecessary who lookup for "..name, 7);
	end
	DuelTracker_PlayerCache[name] = { race = race,
					 class = class,
					 level = level,
					 guild = guild };
	
	whoqueue = whoqueue.next;	-- Advance queue processing

	return;
end

function DuelTracker_FlushWhoQueue()
	whoqueue = nil;
	DuelTracker_WhoRequestStop();
	-- Stop OnUpdate calls
	DuelTrackerFrame:Hide();
end

function DuelTracker_PrintWhoQueue()
	if ( whoqueue == nil ) then
		DuelTracker_Message("No pending requests in queue.", 3);
	else
		DuelTracker_Message("Pending requests for:", 3);
		local wq = whoqueue;
		while ( wq ~= nil ) do
			DuelTracker_Message(wq.drkey.." - "..wq.name, 3);
			wq = wq.next;
		end
	end
end

function DuelTracker_SendWhoRequest()
	if ( whoqueue == nil ) then
		DuelTracker_WhoRequestStop();
		-- Stop OnUpdate calls
		DuelTrackerFrame:Hide();
		return;
	end

	DuelTracker_Message("Sending who request for "..whoqueue.name, 7);

	DuelTracker_WhoRequestStart();
	SendWho(whoqueue.name);
end
