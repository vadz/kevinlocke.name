-- This file is part of DuelTracker.
-- Copyright (c) 2005, 2006 Kevin Locke <kwl7@cornell.edu>
-- DuelTracker is licensed under the terms of the MIT (aka Expat) license
-- the specific terms of the license are available in the COPYING.txt file
-- and online at http://www.opensource.org/licenses/mit-license.html

-- Functions to communicate with other players

function DuelTracker_SendStats(recipient, params)
	if ( not DuelTracker_DataIsValid() ) then
		return;
	end

	local name = gsub(params,"(%s*)([^%s]+)(%s+.*)","%2",1);
	if ( name == nil or name == "" ) then
		name = recipient;
	end

	local classrecord = DuelTracker_RecordByClass(name);

	if ( DuelTracker_Config.hidechat ) then
		ChatFrame:UnregisterEvent("CHAT_MSG_WHISPER_INFORM");
	end

	if ( classrecord == nil ) then
		SendChatMessage("No duels recorded for "..name..".",
				"WHISPER", nil, recipient);
		if ( DuelTracker_Config.hidechat ) then
			ChatFrame:RegisterEvent("CHAT_MSG_WHISPER_INFORM");
		end
		return;
	end

	local classes = { "Druid", "Hunter", "Mage", "Paladin",
			  "Priest", "Rogue", "Shaman", "Warlock", "Warrior" };

	for i, class in ipairs(classes) do
		local winper;
		if ( classrecord[class].wins == 0 ) then
			winper = 0;
		else
			winper = 100 * classrecord[class].wins / 
			(classrecord[class].losses + classrecord[class].wins);
		end

		SendChatMessage(class..":  "..
				classrecord[class].wins.."/"..
				classrecord[class].losses.."/"..
				classrecord[class].fled.."/"..
				classrecord[class].flee.."  "..
				winper.."%", "WHISPER", nil, recipient);
	end

	if ( DuelTracker_Config.hidechat ) then
		ChatFrame:RegisterEvent("CHAT_MSG_WHISPER_INFORM");
	end
end

function DuelTracker_SendError(recipient, command)
	if ( recipient == nil ) then
		return;
	end
	
	local errmsg = "DuelTracker:  ";
	if ( command == nil ) then
		errmsg = "Error, no command specified.";
	else
		errmsg = "Unknown command \""..command.."\".";
	end
	
	SendChatMessage(errmsg, "WHISPER", nil, recipient);
	SendChatMessage("Usage: .duel stats [name]", "WHISPER", nil, recipient);
	return;
end
