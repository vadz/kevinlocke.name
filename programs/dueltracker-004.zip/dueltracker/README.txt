Readme for the World of Warcraft DuelTracker Mod

Installation
------------
Unzip the dueltracker.zip file into the World of Warcraft Interface AddOns 
directory (usually C:\Program Files\World of Warcraft\Interface\AddOns).

Usage
-----
Type "/dueltracker [command]" from the chat window, where [command] is one of 
the following commands:
	_Command_	_Action_
	reset		Clears all of the previously recorded duels.  This 
			effectively resets all statistics to 0, use with 
			caution.
	list		Lists out all previously recorded duels, one per line.
			Note:  If you have been running DuelTracker for a while,
			this list will be quite large.  Use stats instead.
	stats [player]	Prints out the win/loss record for [player], or for the
			user if no player is specified, by class.
	config [opt val]Set a configuration option or list current settings.
	help		Prints a message listing valid commands.

Configuration
-------------
Verbosity:	Select what type of messages will be displayed.
		All messages below the selected verbosity will be displayed
		0	Emergency Messages (Fatal Errors)
		1	Alert (User intervention required)
		2	Error (Something preventing full functionality)
		3	User-Requeted Output
		4	Warning
		5	Normal but significant
		6	Informational
		7	Debugging
		
TargetDueler:	Set this option to true if you want DuelTracker to attempt to 
		target the winner or loser of a duel to gather information.
		This option will limit the number of who queries that are 
		performed, but may interfere with the user's dueling (if the
		target is changed just before a spell cast).
		Note:  DuelTracker will attempt to get information from its 
		cache first, so targetting will not occur every duel.  It will
		also re-target the original target to minimize annoyance.

ChatStat:	Set this option to true if you want DuelTracker to respond to
		whispers from other players requesting player statistics.
		Players should whisper ".duel [player] stats" to get win/loss
		statistics for the specified player or themselves if none is
		specified.

HideChat:	Set this option to true if you want DuelTracker to hide 
		messages responding to requests for statistics from other
		players.
		(Note:  Not yet fully implemented.)

Exporting Statistics
--------------------
DuelTracker supports the ability to export its list of duels and statistics
generated from those duels into CSV (comma-separated value) format.  However,
doing this does require some extra effort above-and-beyond the installation
and usage information above.

First, you will need to install a Lua interpreter.  Free Lua interpreters are
available for Windows, Mac, and many other operating systems from 
http://luabinaries.luaforge.net/ or http://lua-users.org/wiki/LuaBinaries or
anywhere else.  Simply download and unpack the archive.

Next, you will need to edit the dueltracker-export.lua file to look in the 
proper place for the saved duels.  Open dueltracker-export.lua in any text 
editor and change the DuelTracker_DataFile variable to point to your saved-
variables file (usually you just need to change ==YOURACCOUNTNAME== to your
account name - note: double backslashes are required).  Optionally you can
change the DuelTracker_ExportFile and StatFile names to save the records
and statistics to different files.

Finally, you will need to run the dueltracker-export.lua script in the Lua
interpreter.  This can either be done from the command prompt (terminal) 
or by associating the .lua filetype with the interpreter.  From the prompt or
terminal, move to the directory where you installed the Lua interpreter and
run lua /path/to/dueltracker-export.lua (change /path/to to the actual path
to the script).  To associate the .lua filetype with the interpreter on Windows
simply double-click on duelmaster-export.lua then when prompted to select a 
program to open the file, browse to the location where you installed the Lua
interpreter and click on the executable.

This should produce two files, one containing a list of all the duels and 
with statistics for every player observed.  If not, try running the script
from the command prompt/terminal and send me the error message that is produced.

Note:  The CSV file format should be readable by most spreadsheet applications
(including Excel) or easily converted to other usable formats.  For more 
information about CSV, see http://en.wikipedia.org/wiki/Comma-separated_values

Other Information
-----------------
DuelTracker is released under the terms of the MIT (aka Expat) license, the 
terms of this license are in the COPYING.txt file and available online at
http://www.opensource.org/licenses/mit-license.html

Questions, comments, suggestions, bug reports, etc. can all be sent to me
Kevin Locke <kwl7@cornell.edu>.
