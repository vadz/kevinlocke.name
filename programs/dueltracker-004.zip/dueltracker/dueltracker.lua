-- Duel Master - WoW AddOn to keep records of duels and calculate statistics
-- Author:	Kevin Locke <kwl7@cornell.edu>
-- Date:	2006-04-01
-- Revision:	0.04

-- Copyright (c) 2005, 2006 Kevin Locke <kwl7@cornell.edu>
-- DuelTracker is licensed under the terms of the MIT (aka Expat) license
-- the specific terms of the license are available in the COPYING.txt file
-- and online at http://www.opensource.org/licenses/mit-license.html

-- TODO:  Find way to get server date (without assumptions about local time)
-- TODO:  Add Rank information to duel statistics?

-- DuelTracker_DuelRecord:  Array of Duel Results (version1)
-- Contains the time a duel occured (sec. since epoch), the winner, and loser
-- Indexed starting at 1 (in LUA tradition...), contains size field
-- Sorted in ascending order by time (how results arrive)

-- DuelTracker_PlayerCache:  Table of player information indexed by name
-- Advantage:  Saves unnecessary who queries which can interfere with player
-- Disadvantage:  Makes player information static (e.g. always same level)
-- Compromise:  Cache is flushed when DuelTracker is reloaded
-- 
-- To make data static (and avoid many who lookups) add DuelTracker_PlayerCache
-- to the SavedVariables list in DuelTracker.toc
DuelTracker_PlayerCache = {};

-- DuelTracker_Config:  Configuration settings for the DuelTracker mod
DuelTracker_Config = {	verbosity = 3,	-- Higher values => more status msgs.
			targetdueler = false,  -- Target winner/loser for info.
			chatstat = true,  -- Respond to whispers for statistics
			hidechat = false  -- Hide stat responses from user
		    };


-- Constants
DUELTRACKER_VERSION = 0.04;
DUELTRACKER_DATA_VERSION = 1;
DUELTRACKER_VICTORY_DEFEATED = "Defeated";
DUELTRACKER_VICTORY_FLED = "Fled";
local WHO_QUERY_INTERVAL = 7;		-- 7 seconds between who requests

local varloaded = false;		-- true when variables have been loaded
local whoquerytimer = 0;		-- countdown timer for who queries

-- FIXME: Add DuelTracker to the list of chat channels
--[[
CHAT_MSG_DUELTRACKER = "DuelTracker";
ChatTypeInfo["DUELTRACKER"] = { sticky = 0 };
ChatTypeGroup["DUELTRACKER"] = { "CHAT_MSG_DUELTRACKER" };
tinsert(OtherMenuChatTypeGroups, "DUELTRACKER");
--]]

-- Add /dueltracker to the list of "/" commands
SlashCmdList["DUELTRACKER"] = function(msg)
	local command = gsub(msg, "(%s*)([^%s]+)(.*)", "%2", 1);
	local params = gsub(msg, "(%s*)([^%s]+)(.*)", "%3", 1);

	if ( command == "clear" or command == "reset" ) then
		DuelTracker_ClearData();
	elseif ( command == "list" or command == "print" ) then
		DuelTracker_PrintRecords(params);
	elseif ( command == "stat" or command == "stats" ) then
		DuelTracker_PrintStats(params);
	elseif ( strsub(command, 1, 4) == "conf" ) then
		DuelTracker_Configure(params);
	elseif ( command == "whoqueue" ) then
		DuelTracker_PrintWhoQueue();
	else
		DuelTracker_Help(command);
	end
end

SLASH_DUELTRACKER1 = "/dueltracker";

function DuelTracker_OnLoad()
	this:RegisterEvent("CHAT_MSG_SYSTEM");
	this:RegisterEvent("VARIABLES_LOADED");
end

function DuelTracker_OnEvent(event)
	-- Duel messages are sent as system chat messages, handle this event
	if ( event == "CHAT_MSG_SYSTEM" ) then
		local vtype, winner, loser;
	
		-- Check if this is a duel message, exit if not
		if ( not string.find(arg1, "in a duel") ) then
			return;
		elseif ( string.find(arg1, "has defeated") ) then 
			vtype = DUELTRACKER_VICTORY_DEFEATED;
			winner = string.gsub(arg1,
					"(.*) has defeated (.*) in a duel",
					"%1", 1);
			loser = string.gsub(arg1,
					"(.*) has defeated (.*) in a duel",
					"%2", 1);
		elseif ( string.find(arg1, "has fled from") ) then
			vtype = DUELTRACKER_VICTORY_FLED;
			winner = string.gsub(arg1,
					"(.*) has fled from (.*) in a duel",
					"%1", 1);
			loser = string.gsub(arg1,
					"(.*) has fled from (.*) in a duel",
					"%2", 1);
		end

		if ( loser == winner or winner == nil or
		     loser == nil or vtype == nil ) then
			DuelTracker_Message("Error parsing duel.", 2, true);
			DuelTracker_Message("Victory Type:  "..vtype, 2);
			DuelTracker_Message("Winner:  "..winner, 2);
			DuelTracker_Message("Loser:  "..loser, 2);
			return;
		end

		DuelTracker_AddRecord(winner, loser, vtype);
	elseif ( event == "CHAT_MSG_WHISPER" ) then
		if ( not string.find(arg1, ".duel", 1, true) ) then
			return;
		end
		
		local command = gsub(arg1, "(.*\.duel[%s]*)"..
					"([^%s]+)(%s*)(.*)", "%2", 1);
		local params = gsub(arg1, "(.*\.duel[%s]*)"..
					"([^%s]+)(%s*)(.*)", "%4", 1);

		if ( command == "stat" or command == "stats" ) then
			DuelTracker_SendStats(arg2, params);
		else
			DuelTracker_SendError(arg2, command);
		end
	elseif ( event == "VARIABLES_LOADED" ) then
		varloaded = true;
		if ( DuelTracker_Config.chatstat ) then
			this:RegisterEvent("CHAT_MSG_WHISPER");
		end
		DuelTracker_Message("DuelTracker version "..DUELTRACKER_VERSION..
		" loaded.", 5);
	elseif ( event == "WHO_LIST_UPDATE" ) then
		DuelTracker_HandleWhoData();
	end
end

function DuelTracker_OnUpdate(elapsed)
	whoquerytimer = whoquerytimer - elapsed;
	if ( whoquerytimer <= 0 ) then
		DuelTracker_SendWhoRequest();
		whoquerytimer = WHO_QUERY_INTERVAL;
	end
end

function DuelTracker_Configure(params)
	if ( string.gsub(params, "%s", "") == "" ) then
		DuelTracker_Message("DuelTracker configuration options:",3);
		DuelTracker_Message("Option              Value",3);
		for opt,val in pairs(DuelTracker_Config) do
			local msg = string.format("%-20s", opt);
			DuelTracker_Message(msg..tostring(val), 3);
		end
		return;
	end
	
	local opt = string.gsub(params, "%s*([^%s]+)%s+([^%s]+)", "%1", 1);
	opt = string.lower(opt);
	local vals = string.gsub(params, "%s*([^%s]+)%s+([^%s]+)", "%2", 1);
	vals = string.lower(vals);
	local val;

	if ( DuelTracker_Config[opt] == nil ) then
		DuelTracker_Message("Unknown configuration option \""
				   ..opt.."\".", 3);
		return;
	end

	if ( vals == "true" ) then
		val = true;
	elseif ( vals == "false" ) then
		val = false;
	else
		val = tonumber(vals);
	end

	if ( type(val) ~= type(DuelTracker_Config[opt]) ) then
		DuelTracker_Message("Unable to convert \""..vals.."\" to "..
				   type(DuelTracker_Config[opt])..".",3);
	else
		DuelTracker_Config[opt] = val;
		DuelTracker_Message("DuelTracker: "..opt.." now set to "..
				   tostring(val));
	end
end

function DuelTracker_AddRecord(winnername, losername, vtype)
	if ( vtype == nil ) then
		vtype = DUELTRACKER_VICTORY_DEFEATED;	-- Assume defeated
	end

	-- Get time first so it is close for slow clients
	local dueltime = DuelTracker_GetTime();

	if ( not DuelTracker_DataIsValid() ) then
		return;
	end

	local drkey = DuelTracker_DuelRecord.size + 1;	--Next record at size+1

	DuelTracker_Message("Duel Index:  "..drkey, 7);

	DuelTracker_DuelRecord[drkey] = {winner = {name = winnername},
					loser = {name = losername},
					vtype = vtype,
					time = dueltime};
	DuelTracker_DuelRecord.size = drkey;

	-- Add the rest of the winner and loser information
	DuelTracker_AddPlayerData(drkey);
end

function DuelTracker_AddPlayerData(drkey)
	if ( drkey == nil ) then
		drkey = DuelTracker_DuelRecord.size; -- Assume most recent duel
	end

	-- First check the PlayerCache
	-- Then check if this player was dueling
	-- Then check if our target was dueling
	-- Fall back on a who query for information
	-- Repeat for loser
	for i=1,2 do
		local record;
		if ( i == 1 ) then
			record = DuelTracker_DuelRecord[drkey].winner;
		else
			record = DuelTracker_DuelRecord[drkey].loser;
		end
		
		if ( DuelTracker_PlayerCache[record.name] ~= nil ) then
			local cacherec = DuelTracker_PlayerCache[record.name];
			record.race = cacherec.race;
			record.class = cacherec.class;
			record.level = cacherec.level;
			record.guild = cacherec.guild;
		elseif ( UnitName("player") == record.name ) then
			record.race = UnitRace("player");
			record.class = UnitClass("player");
			record.level = UnitLevel("player");
			record.guild = GetGuildInfo("player");
		elseif ( UnitName("target") == record.name ) then
			record.race = UnitRace("target");
			record.class = UnitClass("target");
			record.level = UnitLevel("target");
			record.guild = GetGuildInfo("target");
		elseif ( DuelTracker_Config["targetdueler"] ) then
			-- Save to re-target original player
			local oldtarget = UnitName("target");

			TargetByName(record.name);
			if ( UnitName("target") ~= record.name ) then
				DuelTracker_Message("Unable to target "..
						   record.name..".",7);
				DuelTracker_AddToWhoQueue(record.name, drkey);
			else
				record.race = UnitRace("target");
				record.class = UnitClass("target");
				record.level = UnitLevel("target");
				record.guild = GetGuildInfo("target");
			end

			if ( oldtarget ~= nil ) then
				TargetByName(oldtarget);
			else
				ClearTarget();
			end
		else
			DuelTracker_AddToWhoQueue(record.name, drkey);
		end
	end
end

function DuelTracker_ClearData()
	DuelTracker_DuelRecord = {size = 0, version = DUELTRACKER_DATA_VERSION};
	DuelTracker_FlushWhoQueue();
	DuelTracker_Message("Data cleared.", 3, true);
end

function DuelTracker_PrintRecords(params)
	if ( not DuelTracker_DataIsValid() ) then
		return;
	end

	if ( DuelTracker_DuelRecord.size == 0 ) then
		DuelTracker_Message("No duels have been recorded.", 3);
		return;
	end

	for i,duel in ipairs(DuelTracker_DuelRecord) do
		local time = date(duel.time);
		local winner = duel.winner;
		local loser = duel.loser;
		local vtype = duel.vtype;

		local vmessage;
		if ( vtype == DUELTRACKER_VICTORY_DEFEATED ) then
			vmessage = " defeated ";
		elseif ( vtype == DUELTRACKER_VICTORY_FLED ) then
			vmessage = " was fled from by ";
		else
			vmessage = " did something to ";
		end

		DuelTracker_Message(date("%c",time).."  "..winner.name..
				   vmessage..loser.name..".", 3);
	end
end

function DuelTracker_PrintStats(params)
	if ( not DuelTracker_DataIsValid() ) then
		return;
	end

	local name = string.gsub(params,"(%s*)([^%s]+)(.*)","%2",1);
	if ( name == nil or name == "" ) then
		name = UnitName("player");
	end

	local classrecord = DuelTracker_RecordByClass(name);

	if ( classrecord == nil ) then
		return;
	end

	local classes = { "Druid", "Hunter", "Mage", "Paladin",
			  "Priest", "Rogue", "Shaman", "Warlock", "Warrior" };

	DuelTracker_Message("Duel statistics for "..name..".", 3);
	DuelTracker_Message("Class:  Wins/Losses/Fled From/Flee  Win%", 3);

	for i, class in ipairs(classes) do
		local winper;
		if ( classrecord[class].wins == 0 ) then
			winper = 0;
		else
			winper = 100 * classrecord[class].wins / 
			(classrecord[class].losses + classrecord[class].wins);
		end

		DuelTracker_Message(class..":  "..
				   classrecord[class].wins.."/"..
				   classrecord[class].losses.."/"..
				   classrecord[class].fled.."/"..
				   classrecord[class].flee.."  "..
				   winper.."%", 3);
	end

	return;
end

function DuelTracker_DataIsValid()
	if ( not varloaded ) then
		return false;
	elseif ( DuelTracker_DuelRecord == nil ) then
		DuelTracker_DuelRecord = {size = 0,
					 version = DUELTRACKER_DATA_VERSION};
	else
		local drsize = DuelTracker_DuelRecord.size;
		
		-- Record should have values up to drsize, not past
		if ( drsize == nil or
		     DuelTracker_DuelRecord[drsize] == nil or
		     DuelTracker_DuelRecord[drsize+1] ~= nil ) then
			DuelTracker_RepairSize();
		end
	end

	-- Check version for consistency
	if ( DuelTracker_DuelRecord.version == nil ) then
		DuelTracker_DuelRecord.version = DUELTRACKER_DATA_VERSION;
	elseif ( DuelTracker_DuelRecord.version > DUELTRACKER_DATA_VERSION ) then
		DuelTracker_Message("Data more advanced than program.", 7, true);
	end

	return true;
end

function DuelTracker_RepairSize()
	local drsize = DuelTracker_DuelRecord.size;

	if ( drsize == 0 and DuelTracker_DuelRecord[1] == nil ) then
		DuelTracker_DuelRecord = {size = 0,
					 version = DUELTRACKER_DATA_VERSION};
		return;
	else
		local i = 0;
		while DuelTracker_DuelRecord[i+1] ~= nil do
			i = i + 1;
		end

		DuelTracker_Message("Incorrect size of DuelRecord.", 7);
		DuelTracker_Message("Changing from "..drsize.." to "..i, 7);

		DuelTracker_DuelRecord.size = i;
	end

	return;
end

-- Returns the server time as result of time() - sec. since epoch on Win & POSIX
-- Assumes client is within 12 hours of server time
function DuelTracker_GetTime()
	local hour, minute = GetGameTime();		-- From Server
	local ldate = date("*t");			-- From Client
	local dtime = (ldate.hour*60 + ldate.min) - (hour*60 + minute);

	-- If within 12 hours, use local day
	-- Otherwise, if local day is earlier, need to subtract 1 day
	-- Otherwise, need to add 1 day
	-- FIXME:  Find elegant solution without abusing time()
	if ( math.abs(dtime) > 12*60 ) then
		if ( ldate.hour < hour ) then
			ldate = date("*t", time() - 12*60*60);
		else
			ldate = date("*t", time() + 12*60*60);
		end
	end

	-- Use server hour and minute, set second = 0
	-- FIXME:  Will encounter problems with daylight savings time
	ldate.hour = hour;
	ldate.min = minute;
	ldate.sec = 0;
	return time(ldate);
end

function DuelTracker_GetStatClass(pname)
	if ( not DuelTracker_DataIsValid() ) then
		return;
	end

	local wins, losses, fledfrom, fled = {}, {}, {}, {};
	local i = 1;
	while ( i <= DuelTracker_DuelRecord.size ) do
		local record = DuelTracker_DuelRecord[i]
		if ( record.winner.name == pname ) then
			if ( record.vtype == DUELTRACKER_VICTORY_DEFEATED ) then
				wins[record.loser.race] =
					wins[record.loser.race] + 1;
			elseif ( record.vtype == DUELTRACKER_VICTORY_FLED ) then
				fledfrom[record.loser.race] = 
					fledfrom[record.loser.race] + 1;
			end
		elseif ( record.loser.name == pname ) then
			if ( record.vtype == DUELTRACKER_VICTORY_DEFEATED ) then
				losses[record.winner.race] =
					losses[record.winner.race] + 1;
			elseif ( record.vtype == DUELTRACKER_VICTORY_FLED ) then
				fled[record.winner.race] =
					fled[record.winner.race] + 1;
			end
		end
	end

	return;
end

function DuelTracker_Help(command)
	DuelTracker_Message("Usage:  /dueltracker [command]", 3);
	DuelTracker_Message("Available Commands:", 3);
	DuelTracker_Message("  stats [player]   Prints the player's "..
	                    "win/loss record.");
	DuelTracker_Message("  list             Prints all recorded duels.");
	DuelTracker_Message("  reset            Deletes all recorded duels.");
	DuelTracker_Message("  config [opt val] Lists/Sets configuration "..
	                    "opt to val.");
	DuelTracker_Message("  help             Prints this help text.");
	return;
end

function DuelTracker_Message(text, priority, addname)
	if ( text == nil ) then
		return;
	end
	
	if ( priority == nil ) then
		priority = 3;	-- Assume user-requested output
	end

	-- Message may be called before variables are loaded
	if ( DuelTracker_Config.verbosity ~= nil and
	     DuelTracker_Config.verbosity < priority ) then
		return;		-- Filter messages based on configuration
	end

	if ( addname ) then
		text = "DuelTracker: "..text;
	end
	
	local ttype;
	if ( priority < 3 ) then
		ttype = {};
		ttype.r = 1.0;
		ttype.g = 0;
		ttype.b = 0;
	else
		ttype = ChatTypeInfo["SYSTEM"];
	end

	DEFAULT_CHAT_FRAME:AddMessage(text, ttype.r, ttype.g, ttype.b);
end
