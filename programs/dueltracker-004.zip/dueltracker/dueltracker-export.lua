-- This file is part of DuelTracker.
-- Copyright (c) 2005, 2006 Kevin Locke <kwl7@cornell.edu>
-- DuelTracker is licensed under the terms of the MIT (aka Expat) license
-- the specific terms of the license are available in the COPYING.txt file
-- and online at http://www.opensource.org/licenses/mit-license.html

-- DuelTracker_Datafile - Path to the saved-variables file for dueltracker
-- Relative paths save to location of this file, can be absolute path, such as:
-- DuelTracker_ExportFile = "C:\\Documents and Settings\\Kevin\\Desktop\\Duel.csv"
DuelTracker_DataFile = "C:\\Program Files\\World of Warcraft\\WTF\\Account\\"..
                       "==YOURACCOUNTNAME==\\SavedVariables\\dueltracker.lua";
DuelTracker_ExportFile = "DuelRecords.csv";
DuelTracker_StatFile = "DuelStatistics.csv";

local PlayerStats = {};

	if ( DuelTracker_DuelRecord == nil ) then
		if ( DuelTracker_DataFile == nil ) then
			print("Please specify the location for the "..
			      "DuelTracker data file.");
			return;
		else
			dofile(DuelTracker_DataFile);
		end
	end

	local outfile = assert(io.open(DuelTracker_ExportFile, "w"));
	-- Header Record
	outfile:write("\"Duel Time\","..
		      "\"Victory Type\","..
		      "\"Winner Name\","..
		      "\"Winner Race\","..
		      "\"Winner Class\","..
		      "\"Winner Level\","..
		      "\"Winner Guild\","..
		      "\"Loser Name\","..
		      "\"Loser Race\","..
		      "\"Loser Class\","..
		      "\"Loser Level\","..
		      "\"Loser Guild\"\n");

	local i,j;
	local fields = {"name","race","class","level","guild"}
	for i,duel in ipairs(DuelTracker_DuelRecord) do
		-- Remove nils for output
		for j,field in ipairs(fields) do
			if ( duel.winner[field] == nil ) then
				duel.winner[field] = "";
			end
			if ( duel.loser[field] == nil ) then
				duel.loser[field] = "";
			end
		end

		outfile:write("\""..duel.time.."\",\""..
			      duel.vtype.."\",\""..
			      duel.winner.name.."\",\""..
			      duel.winner.race.."\",\""..
			      duel.winner.class.."\",\""..
			      duel.winner.level.."\",\""..
			      duel.winner.guild.."\",\""..
			      duel.loser.name.."\",\""..
			      duel.loser.race.."\",\""..
			      duel.loser.class.."\",\""..
			      duel.loser.level.."\",\""..
			      duel.loser.guild.."\"\n");

		if ( PlayerStats[duel.winner.name] == nil ) then
			PlayerStats[duel.winner.name] = 
				{race = duel.winner.race,
				 class = duel.winner.class,
				 level = duel.winner.level,
				 guild = duel.winner.guild};
		end
		if ( PlayerStats[duel.loser.name] == nil ) then
			PlayerStats[duel.loser.name] =
				{race = duel.loser.race,
				 class = duel.loser.class,
				 level = duel.loser.level,
				 guild = duel.loser.guild};
		end
		
		if (duel.loser.class ~= "" and
		    PlayerStats[duel.winner.name][duel.loser.class] == nil) then
			PlayerStats[duel.winner.name][duel.loser.class] = 
			{wins = 0, losses = 0, fleewins = 0, fleelosses = 0};
		end
		if (duel.winner.class ~= "" and
		    PlayerStats[duel.loser.name][duel.winner.class] == nil) then
			PlayerStats[duel.loser.name][duel.winner.class] =
			{wins = 0, losses = 0, fleewins = 0, fleelosses = 0};
		end
		
		if ( duel.vtype == "Defeated" ) then
			if ( duel.loser.class ~= "" ) then
		PlayerStats[duel.winner.name][duel.loser.class].wins = 
		PlayerStats[duel.winner.name][duel.loser.class].wins + 1;
			end
			if ( duel.winner.class ~= "" ) then
		PlayerStats[duel.loser.name][duel.winner.class].losses = 
		PlayerStats[duel.loser.name][duel.winner.class].losses+1;
			end
		elseif ( duel.vtype == "Fled" ) then
			if ( duel.loser.class ~= "" ) then
		PlayerStats[duel.winner.name][duel.loser.class].fleewins = 
		PlayerStats[duel.winner.name][duel.loser.class].fleewins + 1;
			end
			if ( duel.winner.class ~= "" ) then
		PlayerStats[duel.loser.name][duel.winner.class].fleelosses = 
		PlayerStats[duel.loser.name][duel.winner.class].fleelosses+1;
			end
		else
			print("Unknown duel victory type "..duel.vtype);
		end
	end

	io.close(outfile);

	local classes = { "Druid", "Hunter", "Mage", "Paladin",
			  "Priest", "Rogue", "Shaman", "Warlock", "Warrior" };
	local statfile = assert(io.open(DuelTracker_StatFile, "w"));

	-- Header Record
	local line = "\"Name\",\"Guild\",\"Race\",\"Class\",\"Level\"";
	for i,class in ipairs(classes) do
		line = line..",\""..class.." Wins\""..
			     ",\""..class.." Losses\""..
			     ",\""..class.." FleeWins\""..
			     ",\""..class.." FleeLosses\"";
	end

	-- Write header line
	statfile:write(line.."\n");
	for name,info in pairs(PlayerStats) do
		line = "\""..name.."\""..
		       ",\""..info.guild.."\""..
		       ",\""..info.race.."\""..
		       ",\""..info.class.."\""..
		       ",\""..info.level.."\"";

		for i,class in ipairs(classes) do
			if ( info[class] == nil ) then
				line = line..",\"0\",\"0\",\"0\",\"0\"";
			else 
				line =line..",\""..info[class].wins.."\""..
					    ",\""..info[class].losses.."\""..
					    ",\""..info[class].fleewins.."\""..
					    ",\""..info[class].fleelosses.."\"";
			end
		end

		statfile:write(line.."\n");
	end

	io.close(statfile);
