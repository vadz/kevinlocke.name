-- This file is part of DuelTracker.
-- Copyright (c) 2005, 2006 Kevin Locke <kwl7@cornell.edu>
-- DuelTracker is licensed under the terms of the MIT (aka Expat) license
-- the specific terms of the license are available in the COPYING.txt file
-- and online at http://www.opensource.org/licenses/mit-license.html

-- Functions to calculate statistics from the DuelTracker data

function DuelTracker_WinLossFledFlee(player)
	if ( not DuelTracker_DataIsValid() or player == nil ) then
		return 0, 0, 0, 0;
	end

	local i = 1;
	local wins, losses, fled, flee = 0, 0, 0, 0;

	while ( DuelTracker_DuelRecord[i] ~= nil ) do
		local duel = DuelTracker_DuelRecord[i];
		if ( duel.winner.name == player ) then
			if ( duel.vtype == DUELTRACKER_VICTORY_DEFEATED ) then
				wins = wins + 1;
			elseif ( duel.vtype == DUELTRACKER_VICTORY_FLED ) then
				fled = fled + 1;
			end
		elseif ( duel.loser.name == player ) then
			if ( duel.vtype == DUELTRACKER_VICTORY_DEFEATED ) then
				losses = losses + 1;
			elseif ( duel.vtype == DUELTRACKER_VICTORY_FLED ) then
				flee = flee + 1;
			end
		end
		i = i + 1;
	end

	return wins, losses, fled, flee;
end

function DuelTracker_RecordByClass(player)
	if ( not DuelTracker_DataIsValid() or player == nil ) then
		DuelTracker_Print("Unable to calculate statistics.");
		return nil;
	end
	
	local classrecord = { Druid = {wins=0,losses=0,fled=0,flee=0},
			      Hunter = {wins=0,losses=0,fled=0,flee=0},
			      Mage = {wins=0,losses=0,fled=0,flee=0},
			      Paladin = {wins=0,losses=0,fled=0,flee=0},
			      Priest = {wins=0,losses=0,fled=0,flee=0},
			      Rogue = {wins=0,losses=0,fled=0,flee=0},
			      Shaman = {wins=0,losses=0,fled=0,flee=0},
			      Warlock = {wins=0,losses=0,fled=0,flee=0},
			      Warrior = {wins=0,losses=0,fled=0,flee=0} };

	for i,duel in ipairs(DuelTracker_DuelRecord) do
		if ( string.lower(duel.winner.name) == string.lower(player) and
		     duel.loser.class ~= nil) then
			if ( duel.vtype == DUELTRACKER_VICTORY_DEFEATED ) then
				classrecord[duel.loser.class].wins =
					classrecord[duel.loser.class].wins + 1;
			elseif ( duel.vtype == DUELTRACKER_VICTORY_FLED ) then
				classrecord[duel.loser.class].fled =
					classrecord[duel.loser.class].fled + 1;
			end
		elseif ( string.lower(duel.loser.name)==string.lower(player) and
			 duel.winner.class ~= nil ) then
			if ( duel.vtype == DUELTRACKER_VICTORY_DEFEATED ) then
				classrecord[duel.winner.class].losses =
				     classrecord[duel.winner.class].losses + 1;
			elseif ( duel.vtype == DUELTRACKER_VICTORY_FLED ) then
				classrecord[duel.winner.class].flee =
					classrecord[duel.winner.class].flee + 1;
			end
		end
	end

	return classrecord;
end
